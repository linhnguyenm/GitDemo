//
//  AppDelegate.h
//  GitDemo
//
//  Created by Linh Nguyen on 5/16/16.
//  Copyright © 2016 Linh Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

