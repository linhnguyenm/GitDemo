//
//  ViewController.h
//  GitDemo
//
//  Created by Linh Nguyen on 5/16/16.
//  Copyright © 2016 Linh Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong)NSString *someProperty;
@end

